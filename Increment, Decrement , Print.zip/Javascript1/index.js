let count=0;

function increment(){
    count += 1;
    document.getElementById("number").innerHTML = count;
}

function decrement(){
    count -= 1;
    if(count<0){
        count=0;
    }
    document.getElementById("number").innerHTML = count;
}

function save(){
    if(count>0){
        document.getElementById("save").innerHTML += " "+count+",";
    }
}